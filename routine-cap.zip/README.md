# Routine — やることリスト（iOS / iPad / Mac アプリ）

PWA をそのまま Capacitor でネイティブ化したものです。`www/` の中身が画面、ネイティブ側で
**OSのローカル通知**を使うので、アプリを閉じていても設定した時刻に通知が鳴ります。

対応：iPhone / iPad（ネイティブ）、Mac（Apple Silicon なら iPad アプリとして実行可）、Web（`www/` を https に置けば従来どおり）。

---

## 必要なもの（Mac）
- **Xcode**（App Store から無料。初回起動でコマンドラインツールも入れる）
- **Node.js 18 以上**（`node -v` で確認。無ければ https://nodejs.org または `brew install node`）
- **CocoaPods**（`sudo gem install cocoapods`。Apple Silicon で詰まる場合は `brew install cocoapods`）
- Apple ID（自分の端末に入れるだけなら無料アカウントでOK。7日ごとに再ビルドが必要）

## セットアップ（ターミナルでこのフォルダに移動して順に実行）

```bash
cd routine-cap

# 1) 依存をインストール
npm install

# 2) iOS プロジェクトを追加（初回のみ）
npx cap add ios

# 3) www の中身をネイティブへ反映（コードを変えるたびに実行）
npx cap sync

# 4) Xcode で開く
npx cap open ios
```

## Xcode 側の操作
1. 左の「App」ターゲット → **Signing & Capabilities** で **Team** に自分の Apple ID を選ぶ
   （`com.routine.todo` が誰かと衝突したら **Bundle Identifier** を `com.あなたの名前.routine` などに変更）
2. 上部のデバイス選択：
   - iPhone/iPad 実機：ケーブルで接続して選択（初回は端末側で「設定 > 一般 > VPNとデバイス管理」から開発者を信頼）
   - Mac で動かす：**My Mac (Designed for iPad)** を選択
3. ▶︎ Run。初回起動時に通知の許可を求められるので「許可」。

## アプリアイコンの設定
`resources_icon-1024.png` を 1024×1024 のアイコン素材として使えます。手軽なのは：

```bash
npm i -D @capacitor/assets
mkdir -p assets && cp resources_icon-1024.png assets/icon.png
npx capacitor-assets generate --ios
```

これで各サイズが自動生成され、Xcode の AppIcon に入ります。
（手動なら Xcode の `Assets.xcassets > AppIcon` に 1024 画像をドラッグでも可）

---

## 通知のしくみ
- **ルーティン**（時刻あり）→ 毎日 or 指定曜日にくり返す通知を予約
- **単発の今日タスク**（時刻あり）→ その時刻に1回だけ通知
- 完了・削除・編集すると予約を自動で組み直します（OSが管理するのでアプリは閉じていてOK）

## 困ったとき
- ビルドが落ちる：`npx cap sync` をやり直し、Xcode を再起動。`npx cap doctor` でバージョン不整合を確認
- 画面が真っ白：`npx cap sync` 忘れ。`www/index.html` がコピーされているか確認
- 通知が来ない：iOS の「設定 > 通知 > Routine」で許可されているか、集中モードでないか確認

## コードを直したいとき
画面は全部 `www/index.html` の1ファイルです。直したら `npx cap sync` → Xcode で Run。
Web 版として配るなら `www/` をそのまま https サーバーに置けば動きます。
